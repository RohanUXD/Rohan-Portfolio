import { motion } from 'framer-motion';
import '@fontsource/inter';

export default function Banner() {
  const handleRedirect = () => {
    window.location.href = 'https://rohanux.framer.ai';
  };

  return (
    <motion.div 
      className="w-full bg-white p-6 md:p-12 flex flex-col items-center justify-center min-h-[300px] gap-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
    >
      <motion.p 
        className="text-xl md:text-2xl lg:text-3xl text-black max-w-3xl text-center font-inter leading-relaxed"
        initial={{ scale: 0.95 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.2, duration: 0.5 }}
      >
        Hey, I am <span className="font-semibold">Rohan Kamble</span>, a UX Designer. 
        Here's my portfolio. Check it out and let me know if we can work together to create a great experience.
      </motion.p>
      
      <motion.div
        className="relative p-[3px] bg-gradient-to-r from-[#03a9f4] to-[#f441a5] rounded-[0.9em] group"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.5, duration: 0.5 }}
      >
        <motion.button
          onClick={handleRedirect}
          className="text-[1.4em] py-[0.6em] px-[0.8em] rounded-[0.5em] bg-black text-white cursor-pointer shadow-[2px_2px_3px_rgba(0,0,0,0.7)] relative z-10"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Go Ahead
        </motion.button>
        <div className="absolute inset-0 bg-gradient-to-r from-[#03a9f4] to-[#f441a5] rounded-[0.9em] opacity-0 group-hover:opacity-100 group-hover:blur-[1.2em] group-active:blur-[0.2em] transition-all duration-400 -z-10" />
      </motion.div>
    </motion.div>
  );
}