import Banner from './components/Banner';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Banner />
    </div>
  );
}

export default App;