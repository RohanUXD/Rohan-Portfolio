// Add smooth scroll behavior for the CTA button
document.querySelector('.cta-button').addEventListener('click', function() {
    // Smooth scroll to portfolio section (you can update the selector as needed)
    const portfolioSection = document.querySelector('#portfolio') || document.body;
    portfolioSection.scrollIntoView({ behavior: 'smooth' });
});